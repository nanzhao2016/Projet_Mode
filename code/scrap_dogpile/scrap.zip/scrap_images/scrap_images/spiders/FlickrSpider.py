import scrapy
from scrap_images.items import ImageItem
from . import keywords

class FlickrSpider(scrapy.Spider):
    name = 'flickr'

    def start_requests(self):
        url_template = 'https://www.flickr.com/search/?text={}'

        for keyword in keywords:
            yield scrapy.Request(url_template.format(keyword), self.parse)


    def parse(self, response):
        sel = scrapy.Selector(response)
        title = sel.xpath('//title/text()').extract()
        urls = sel.xpath('//script').re('img.src=\'//(.*)\';')
        urls = ['http://' + url for url in urls]
        item = ImageItem()
        item['title'] = title[0]
        item['image_urls'] = urls
        yield item