# This package will contain the spiders of your Scrapy project
#
# Please refer to the documentation for information on how to create and manage
# your spiders.


# motifs = [u'spot', u'rayure', u'squre', u'strips ', u'carreau', u'dentelle', u'less', u'fleur', u'papillon',
#           u'chat', u'star', u'rond', u'plante', u'flamme', u'feu', u'hibou', u'lys', u'motif', u'plume', u'goute',
#           u'coeur', u'eclair', u'vague', u'scotish clan', u'kilt', u'retro', u'tete de mort', u'chidori ',
#           u'soleil', u'lune', u'feuille', u'palmier', u'poisson', u'dauphin', u'rayure', u'triangle',
#           u'motif circulaire', u'pagne wax', u'patchwork', u'seanless']
#
# adjectives = ['petits', 'petit', 'moyens', 'moyen', 'gros', 'courts', 'long']
#
# colours = ['rouge', 'bleu', 'vert', 'gris', 'jaune', 'noir', 'rose', 'violet']
#
#
# def func(ele):
#     res = []
#     for adjective in adjectives:
#         for colour in colours:
#             res.append(ele + ' ' + adjective + ' ' + colour)
#     return res
#
# keywords = []
# for ele in map(func, motifs):
#     keywords.extend(ele)

keywords = ['soleil', 'sun']