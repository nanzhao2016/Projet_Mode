import scrapy

from scrap_images.items import ImageItem
from . import keywords


class GoogleSpider(scrapy.Spider):
    name = 'google'

    def start_requests(self):
        url_template = 'https://www.google.fr/search?newwindow=1&safe=strict&hl=en&site=imghp&tbm=isch&source=hp&biw=1472&bih=649&q={}'

        for keyword in keywords:
                yield scrapy.Request(url_template.format(keyword), self.parse)

    def parse(self, response):
        sel = scrapy.Selector(response)
        title = sel.xpath('//title/text()').extract()
        urls = sel.xpath('//img/@src').extract()
        item = ImageItem()
        item['title'] = title
        item['image_urls'] = urls
        yield item
