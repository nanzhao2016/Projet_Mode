import scrapy
from scrap_images.items import ImageItem
import re
from . import keywords

class Yandex(scrapy.Spider):
    name = 'dogpile'

    def start_requests(self):
        url_template = 'http://www.dogpile.com/search/images?q={}'

        for keyword in keywords:
            yield scrapy.Request(url_template.format(keyword), self.parse)


    def parse(self, response):
        sel = scrapy.Selector(response)
        title = sel.xpath('//title/text()').extract()
        urls = sel.xpath('//img/@src').extract()
        urls_filtered = []
        for url in urls:
            if 'https' in url:
                urls_filtered.append(url)
        links = sel.xpath('//a').extract()
        for element in links:
            if 'Next' in element:
                next_page = re.search('href=\"(.*)\"', element).group(1)
                break
        next_page = next_page.replace('amp;', '', 100)
        next_page = 'http://www.dogpile.com' + next_page
        yield scrapy.Request(next_page, self.parse)

        item = ImageItem()
        item['title'] = title
        item['image_urls'] = urls_filtered
        yield item